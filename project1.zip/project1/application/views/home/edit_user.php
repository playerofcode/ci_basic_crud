<div class="container">
	<div class="row my-5">
		<div class="col-md-12">
			<?php foreach($users as $key):?>
			<form action="<?php echo base_url('home/updateUser/'.$key->id);?>" method="POST">
        	<div class="form-group">
        		<input type="text" name="name" placeholder="Enter Name" value="<?php echo $key->name;?>" class="form-control">
        	</div>
        	<div class="form-group">
        		<input type="text" name="mobno" placeholder="Enter Mobile Number" value="<?php echo $key->mobno;?>" class="form-control">
        	</div>
        	<div class="form-group">
        		<input type="text" name="email" placeholder="Enter Email" value="<?php echo $key->email;?>" class="form-control">
        	</div>
        	<div class="form-group">
        		<input type="submit" value="Update User" class="btn btn-danger">
        	</div>
        <?php endforeach;?>
        </form>
		</div>
	</div>
</div>