<div class="container-fluid">
	<div class="row py-2 bg-dark text-white">
		<div class="col-md-12 text-center">
			Developed by Player Of Code Team
		</div>
	</div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>