<div class="container">
	<div class="row my-2">
		<div class="col-md-12">
			<?php 
			if(!empty($this->session->flashdata('msg'))): ?>
			<div class="alert alert-info" role="alert">
  			<?php echo $this->session->flashdata('msg'); ?>
		</div>
	<?php endif; ?>
			<div class="card">
				<div class="card-header bg-warning">
					<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">+ Add User</button>
				</div>
				<div class="card-body">
					<table class="table table-bordered table-hover">
						<thead>
							<tr>
								<th>S.NO.</th>
								<th>Name</th>
								<th>Mobile Number</th>
								<th>Email</th>
								<th>Edit</th>
								<th>Delete</th>
							</tr>
						</thead>
						<tbody>
							<?php $i=1;foreach ($users as $key): ?>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $key->name;?></td>
								<td><?php echo $key->mobno;?></td>
								<td><?php echo $key->email;?></td>
								<td><a class="btn btn-primary btn-sm" href="<?php echo base_url('home/editUser/'.$key->id);?>">Edit</a></td>
								<td><a class="btn btn-danger btn-sm" href="<?php echo base_url('home/deleteUser/'.$key->id);?>">Delete</a></td>
							</tr>	
							<?php $i++;endforeach ?>
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url('home/insertUser');?>" method="POST">
        	<div class="form-group">
        		<input type="text" name="name" placeholder="Enter Name" class="form-control">
        	</div>
        	<div class="form-group">
        		<input type="text" name="mobno" placeholder="Enter Mobile Number" class="form-control">
        	</div>
        	<div class="form-group">
        		<input type="text" name="email" placeholder="Enter Email" class="form-control">
        	</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add User</button>
      </div>
      </form>
    </div>
  </div>
</div>

