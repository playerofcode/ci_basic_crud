<?php

class Home_model extends CI_Model{
	public function addUser($data)
	{
		return $this->db->insert('users',$data); //Insert data Create
	}
	public function getUserData($id='')
	{
		if($id):
		return $this->db->get_where('users',array('id'=>$id))->result();
		else:
		$this->db->order_by('id','desc');
		return $this->db->get('users')->result(); //Retrieve data Read
		endif;
	}
	public function deleteUser($id)
	{
		return $this->db->delete('users',array('id'=>$id));//Delete Data
	}
	public function updateUser($data,$id)
	{
		 $this->db->where('id',$id);
		 return $this->db->update('users',$data);//update
	}
}
?>