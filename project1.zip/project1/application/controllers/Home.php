<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct() {
        parent::__construct();
  	$this->load->model('Home_model','model');
    }
	public function index()
	{
		$data['users']=$this->model->getUserData();
		$this->load->view('home/header');
		$this->load->view('home/index',$data);
		$this->load->view('home/footer');
	}
	public function about()
	{
		$this->load->view('home/header');
		$this->load->view('home/about');
		$this->load->view('home/footer');
	}
		public function contact()
	{
		$this->load->view('home/header');
		$this->load->view('home/contact');
		$this->load->view('home/footer');
	}
	public function insertUser()
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$mobno=$this->input->post('mobno');
		$data=array(
			'name'=>$name,
			'email'=>$email,
			'mobno'=>$mobno
		);
		
		if($this->model->addUser($data)):
			$this->session->set_flashdata('msg', 'User Added Successfully');
			redirect(base_url('home/index'));
		else:
			$this->session->set_flashdata('msg', 'Something went wrong');
			redirect(base_url('home/index'));
		endif;
	}
	public function deleteUser($id)
	{
		if($this->model->deleteUser($id)):
			$this->session->set_flashdata('msg', 'User deleted Successfully');
			redirect(base_url('home/index'));
		else:
			$this->session->set_flashdata('msg', 'Something went wrong');
			redirect(base_url('home/index'));
		endif;
	}
	public function editUser($id)
	{
		$data['users']=$this->model->getUserData($id);
		$this->load->view('home/header');
		$this->load->view('home/edit_user',$data);
		$this->load->view('home/footer');
	}
	public function updateUser($id)
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$mobno=$this->input->post('mobno');
		$data=array(
			'name'=>$name,
			'email'=>$email,
			'mobno'=>$mobno
		);
		
		if($this->model->updateUser($data,$id)):
			$this->session->set_flashdata('msg', 'User updated Successfully');
			redirect(base_url('home/index'));
		else:
			$this->session->set_flashdata('msg', 'Something went wrong');
			redirect(base_url('home/index'));
		endif;
	}
}
